let foo = 0;
let bar = 0;

function divideBy()
 {
     foo = document.getElementById("first number").value;
     bar = document.getElementById("second number").value;
     let result = foo / bar;
     if(Number.isFinite(result)) {
            console.log(result);
        
     } else {
        alert('You cant divide us!');
     }
 }
